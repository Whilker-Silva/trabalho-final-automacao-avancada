import org.junit.Test;

import simulacao.pkg.banco.*;
import simulacao.pkg.driver.Driver;

public class BotPaymentTest {

    @Test
    public void testConcurrentBotPayments() throws InterruptedException {

       Driver driver1 = new Driver("driver1", "driver1");
       Driver driver2 = new Driver("driver2", "driver2");
       Driver driver3 = new Driver("driver3", "driver3");




        
    }
}
