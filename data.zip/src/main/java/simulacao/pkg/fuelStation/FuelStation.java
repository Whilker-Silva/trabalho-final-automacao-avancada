package simulacao.pkg.fuelStation;

public class FuelStation {
    
}
