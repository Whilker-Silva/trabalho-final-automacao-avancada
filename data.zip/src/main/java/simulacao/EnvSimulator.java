package simulacao;

import java.io.IOException;

import it.polito.appeal.traci.SumoTraciConnection;
import de.tudresden.sumo.util.SumoCommand;
import de.tudresden.sumo.cmd.Vehicle;
import de.tudresden.sumo.objects.SumoStringList;
import simulacao.pkg.banco.AlphaBank;
import simulacao.pkg.company.Company;
import simulacao.pkg.driver.Driver;

public class EnvSimulator extends Thread {

	private static final int QTD_DRIVERS = 20;
	private static final int stepTime = 1;

	private static SumoTraciConnection sumo;
	private Driver[] listaDrivers;
	private int carsInsimulation;
	private static int carsExcutados;
	private static boolean executarPasso;

	private static Object lock = new Object();

	public EnvSimulator() {
		setName("simulador");

		String sumoBin = "sumo-gui";
		String configFile = "map/map.sumo.cfg";

		sumo = new SumoTraciConnection(sumoBin, configFile);
		sumo.addOption("start", "1"); // auto-run on GUI show
		sumo.addOption("quit-on-end", "1"); // auto-close on end

		AlphaBank.getInstancia().start();
		Company.getInstance().start();

		listaDrivers = new Driver[QTD_DRIVERS];
		for (int i = 0; i < QTD_DRIVERS; i++) {
			String login = "driver" + (i + 1);
			String senha = "driver" + (i + 1);
			listaDrivers[i] = new Driver(login, senha);
			listaDrivers[i].setName(login);
		}

		executarPasso = false;
	}

	public void run() {
		try {

			sumo.runServer(12345);

			for (int i = 0; i < QTD_DRIVERS; i++) {
				listaDrivers[i].start();
			}

			while (Driver.getCounter() > 0) {
				SumoStringList carList = (SumoStringList) sumo.do_job_get(Vehicle.getIDList());
				carsInsimulation = carList.size();
				carsExcutados = 0;

				sumo.do_timestep();

				executarPasso = true;
				synchronized (lock) {
					while (carsExcutados < carsInsimulation) {
						lock.wait(100);
					}
				}
				executarPasso = false;

				sleep(stepTime);
			}

			System.out.println("\nRotas executadas com sucesso!\n");
			Company.getInstance().shutdown();
			AlphaBank.getInstancia().shutdown();
			sumo.close();
		}

		catch (IOException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static SumoTraciConnection getSumo() {
		return sumo;
	}

	public static int getSteptime() {
		return stepTime;
	}

	public static void passoExecutado() {
		synchronized (lock) {
			carsExcutados++;
			lock.notifyAll();
		}
	}

	public static boolean getExecutarPasso() {
		return executarPasso;
	}

}
